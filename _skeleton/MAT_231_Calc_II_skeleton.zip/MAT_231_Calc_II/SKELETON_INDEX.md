# MAT_231_Calc_II — skeleton zip

Built 2026-11-27 13:29 by tools/make_smart_zip.py · repo HEAD: 8c8052a 2026-11-24 Added a column, reorganized top level.

This is a cut-down copy of the MAT 231 study-hub repo for uploading into a chat: code and authored content are
included, large binaries are not. Every file that was left out is listed below with its size, so its path and
existence are known even though its bytes are absent. Paths are relative to the repo root.

- Full repo: 470 files, 39.6 MB
- In this zip: 71 files, 473.4 KB uncompressed
- Cut: 202 legacy copy (pre-chapter layout; live tree is ch<N>/) (19.1 MB); 149 image (12.5 MB); 16 pdf (6.8 MB); 31 vendor (KaTeX / fonts, third-party) (621.4 KB); 1 generated (tools/extract_slide_text.py) (110.7 KB)

Read README.md first: it documents the layout (course home → ch<N>/ chapter hubs), the data files
(assets/js/chapters.js, outline.js, slides.js, manifest.js) and the steps for adding a chapter.

## Files left out

- `assets/img/apple-touch-icon.png` — 2.9 KB · image
- `assets/img/favicon-32.png` — 633 B · image
- `assets/img/favicon.ico` — 2.8 KB · image
- `assets/img/icon-512.png` — 10.0 KB · image
- `assets/img/site-preview.png` — 201.5 KB · image
- `assets/js/slide-text.js` — 110.7 KB · generated (tools/extract_slide_text.py)
- `assets/vendor/fonts/LICENSE-Orbitron.txt` — 4.3 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/fonts/LICENSE-ShareTechMono.txt` — 4.3 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/fonts/orbitron-latin-500-normal.woff2` — 6.4 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/fonts/orbitron-latin-700-normal.woff2` — 6.4 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/fonts/orbitron-latin-900-normal.woff2` — 6.2 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/fonts/share-tech-mono-latin-400-normal.woff2` — 13.2 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/katex/LICENSE` — 1.1 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/katex/katex.min.css` — 23.3 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/katex/katex.min.js` — 266.1 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/katex/contrib/auto-render.min.js` — 3.4 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/katex/contrib/mhchem.min.js` — 32.9 KB · vendor (KaTeX / fonts, third-party)
- `assets/vendor/katex/fonts/` — 20 files (.woff2), 253.7 KB · vendor (KaTeX / fonts, third-party)
- `ch11/hw/hw-11-1/img/` — 24 files (.png), 2.2 MB · image
- `ch11/hw/hw-11-10/img/` — 12 files (.png), 792.3 KB · image
- `ch11/hw/hw-11-2/img/` — 28 files (.png), 2.6 MB · image
- `ch11/hw/hw-11-3/img/` — 16 files (.png), 1.4 MB · image
- `ch11/hw/hw-11-4/img/` — 14 files (.png), 1.3 MB · image
- `ch11/hw/hw-11-5/img/` — 14 files (.png), 1.3 MB · image
- `ch11/hw/hw-11-6/img/` — 14 files (.png), 1.1 MB · image
- `ch11/hw/hw-11-8/img/` — 14 files (.png), 1.0 MB · image
- `ch11/hw/hw-11-9/img/` — 8 files (.png), 601.9 KB · image
- `ch11/slides/` — 16 files (.pdf), 6.8 MB · pdf
- `hw/` — 162 files (.html, .js, .png), 12.4 MB · legacy copy (pre-chapter layout; live tree is ch<N>/)
- `quizzes/` — 24 files (.html, .js), 146.2 KB · legacy copy (pre-chapter layout; live tree is ch<N>/)
- `slides/` — 16 files (.html, .pdf), 6.6 MB · legacy copy (pre-chapter layout; live tree is ch<N>/)

## Files included

- `.nojekyll` — 0 B
- `README.md` — 11.0 KB
- `index.html` — 7.5 KB
- `outline.html` — 6.7 KB
- `search.html` — 12.7 KB
- `viewer.html` — 8.0 KB
- `assets/css/quiz.css` — 16.2 KB
- `assets/css/site.css` — 30.6 KB
- `assets/js/chapters.js` — 2.4 KB
- `assets/js/hub.js` — 10.6 KB
- `assets/js/hw-engine.js` — 10.8 KB
- `assets/js/manifest.js` — 10.2 KB
- `assets/js/nav.js` — 2.0 KB
- `assets/js/outline.js` — 13.4 KB
- `assets/js/quiz-engine.js` — 22.3 KB
- `assets/js/slides.js` — 5.3 KB
- `ch10/index.html` — 3.4 KB
- `ch11/index.html` — 3.4 KB
- `ch11/hw/hw-11-1/data.js` — 13.6 KB
- `ch11/hw/hw-11-1/index.html` — 2.3 KB
- `ch11/hw/hw-11-10/data.js` — 6.2 KB
- `ch11/hw/hw-11-10/index.html` — 2.3 KB
- `ch11/hw/hw-11-2/data.js` — 14.5 KB
- `ch11/hw/hw-11-2/index.html` — 2.3 KB
- `ch11/hw/hw-11-3/data.js` — 10.0 KB
- `ch11/hw/hw-11-3/index.html` — 2.3 KB
- `ch11/hw/hw-11-4/data.js` — 10.9 KB
- `ch11/hw/hw-11-4/index.html` — 2.3 KB
- `ch11/hw/hw-11-5/data.js` — 9.9 KB
- `ch11/hw/hw-11-5/index.html` — 2.3 KB
- `ch11/hw/hw-11-6/data.js` — 8.1 KB
- `ch11/hw/hw-11-6/index.html` — 2.3 KB
- `ch11/hw/hw-11-8/data.js` — 7.7 KB
- `ch11/hw/hw-11-8/index.html` — 2.3 KB
- `ch11/hw/hw-11-9/data.js` — 5.6 KB
- `ch11/hw/hw-11-9/index.html` — 2.3 KB
- `ch11/quizzes/quiz-11-1/data.js` — 14.2 KB
- `ch11/quizzes/quiz-11-1/index.html` — 3.0 KB
- `ch11/quizzes/quiz-11-10/data.js` — 7.8 KB
- `ch11/quizzes/quiz-11-10/index.html` — 3.0 KB
- `ch11/quizzes/quiz-11-2/data.js` — 9.1 KB
- `ch11/quizzes/quiz-11-2/index.html` — 3.0 KB
- `ch11/quizzes/quiz-11-3/data.js` — 9.6 KB
- `ch11/quizzes/quiz-11-3/index.html` — 3.0 KB
- `ch11/quizzes/quiz-11-4/data.js` — 12.2 KB
- `ch11/quizzes/quiz-11-4/index.html` — 3.0 KB
- `ch11/quizzes/quiz-11-5/data.js` — 10.7 KB
- `ch11/quizzes/quiz-11-5/index.html` — 3.0 KB
- `ch11/quizzes/quiz-11-6/data.js` — 11.2 KB
- `ch11/quizzes/quiz-11-6/index.html` — 3.0 KB
- `ch11/quizzes/quiz-11-8/data.js` — 7.6 KB
- `ch11/quizzes/quiz-11-8/index.html` — 3.0 KB
- `ch11/quizzes/quiz-11-9/data.js` — 8.8 KB
- `ch11/quizzes/quiz-11-9/index.html` — 3.0 KB
- `ch11/quizzes/quiz-tests-guide/data.js` — 7.4 KB
- `ch11/quizzes/quiz-tests-guide/index.html` — 3.0 KB
- `ch11/quizzes/review-quiz-3-3/data.js` — 4.1 KB
- `ch11/quizzes/review-quiz-3-3/index.html` — 3.0 KB
- `ch11/quizzes/review-quiz-3-4/data.js` — 7.7 KB
- `ch11/quizzes/review-quiz-3-4/index.html` — 3.0 KB
- `ch11/slides/src/11.2_Series_Problems.tex` — 10.1 KB
- `ch6/index.html` — 3.4 KB
- `ch7/index.html` — 3.4 KB
- `ch8/index.html` — 3.4 KB
- `tools/build_manifest.js` — 2.9 KB
- `tools/chapter_page_template.html` — 3.4 KB
- `tools/extract_slide_text.py` — 1.7 KB
- `tools/hw_page_template.html` — 2.3 KB
- `tools/make_smart_zip.py` — 8.4 KB
- `tools/quiz_helpers.txt` — 913 B
- `tools/quiz_page_template.html` — 3.0 KB
